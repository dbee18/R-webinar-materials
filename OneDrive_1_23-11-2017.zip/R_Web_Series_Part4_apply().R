#When do we use apply? 
#When we have some structured blob of data that we wish to 
#perform operations on.

#The operations may be informational, or perhaps transforming,
#subsetting, whatever to the data.

# Construct a 5x6 matrix
X <- matrix(rnorm(30), nrow=5, ncol=6)
X
# Sum the values of each column with `apply()`
apply(X, 2, mean)

#lapply - for lists and can also be applied on dataframes but the 
#returned object is list.
#it returns the n no of output for the n nos of inputs

ob1 <- lapply(1:3, function(x) x^2)
class(ob1)

ob2 <-sapply(1:3, function(x) x^2)
class(ob2)

#On explicitly mentioning simplify = FALSE its produces a list too.

ob3 <-sapply(1:3, function(x) x^2, simplify = FALSE)

#mapply()
#The mapply() function stands for 'multivariate' apply
#Its purpose is to be able to vectorize arguments to a function
##that is not usually accepting vectors as arguments.

#mapply() applies a Function to Multiple List or multiple Vector 
##Arguments.

# Create a 4x4 matrix
Q1 <- matrix(c(rep(1, 4), rep(2, 4), rep(3, 4), rep(4, 4)),4,4)

# Print `Q1`
print(Q1)

# Or use `mapply()`
Q2 <- mapply(rep,1:4,4)

# Print `Q2`
print(Q2)

