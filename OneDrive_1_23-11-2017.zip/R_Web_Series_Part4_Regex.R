#install.packages("stringr")
library("stringr")

setwd("C:/AI_Related/DataSet")
getwd()
files <- list.files()
class(files)
head(files)

grep("movie", files, value = TRUE)

grep("movie", files, value = FALSE)

grep("movie", files, value = TRUE, invert = TRUE)

grepl("movie", files)

#Regular expressions typically specify characters 
#(or character classes) to seek out, possibly with 
#information about repeats and location within the string

#$ * + . ? [ ] ^ { } | ( ) \ - metacharacters

#There are some special characters in R that cannot be 
#directly coded in a string.

gDat <- read.delim("gapminderDataFiveYear.txt")
str(gDat)

#The Escape sequence is \

levels(gDat$country)

grep('\'', levels(gDat$country), value = TRUE)
#Knowledge Check
grep("'", levels(gDat$country), value = TRUE)

#Option 1 - Cote d'Ivoire
#Option 2 - No Output
#Option 3 - Error

#Escape sequence is required for 
######',",\n,\r,\t

#Point to be noted cat and print handles these in two different ways.

print("a\nb")

cat("a\nb")

#Knowledge Check:
#cat("a\\nb")
#Option 1 : a\nb
#Option 2 : a and b in next line
#Option 3 : Error

#Quantifiers specify how many repetitions of the pattern.

#*: matches at least 0 times.
#+: matches at least 1 times.
#?: matches at most 1 times.
#{n}: matches exactly n times.
#{n,}: matches at least n times.
#{n,m}: matches between n and m times.

strings <- c("a", "ab", "acb", "accb", "acccb", "accccb")

grep("ac*b", strings, value = TRUE)

grep("ac+b", strings, value = TRUE)

grep("ac?b", strings, value = TRUE)

grep("ac{2}b", strings, value = TRUE)

grep("ac{2,}b", strings, value = TRUE)

grep("ac{2,3}b", strings, value = TRUE)

#Position of pattern within the string
#^: matches the start of the string.
#$: matches the end of the string.


strings <- c("abcd", "cdabxy", "cabd", "cdab")

grep("ab", strings, value = TRUE)

grep("^ab", strings, value = TRUE)

grep("ab$", strings, value = TRUE)


#Operators
#.: matches any single character, as shown in the first example.
#[...]: a character list, matches any one of the characters inside
##the square brackets. We can also use  - inside the brackets to
##specify a range of characters.
#[^...]: an inverted character list, similar to [...], but matches
##any characters except those inside the square brackets.
#\: suppress the special meaning of metacharacters in regular 
##expression, i.e.  $ * + . ? [ ] ^ { } | ( ) \, similar to its 
##usage in escape sequences. Since \ itself needs to be escaped 
##in R, we need to escape these metacharacters with double 
##backslash like \\$.
#|: an "or" operator, matches patterns on either side of the |.
#(...): grouping in regular expressions. This allows you to 
##retrieve the bits that matched various parts of your regular 
##so you can alter them or use them for building up a new string.

(strings <- c("^ab", "ab", "abc", "abd", "abe", "ab 12"))

grep("ab.", strings, value = TRUE)

grep("ab[c-e]", strings, value = TRUE)

grep("ab[c-e]", strings, value = TRUE)

grep("ab[^c]", strings, value = TRUE)

grep("^ab", strings, value = TRUE)

gsub("(ab) 12", "\\1 34", strings)

#Character classes allows to - surprise! - specify entire classes
##of characters, such as numbers, letters, etc.

#[:digit:] or \d: digits, 0 1 2 3 4 5 6 7 8 9, equivalent to [0-9].
#\D: non-digits, equivalent to [^0-9].
#[:lower:]: lower-case letters, equivalent to [a-z].
#[:upper:]: upper-case letters, equivalent to [A-Z].
#[:alpha:]: alphabetic characters, equivalent to [[:lower:][:upper:]] or [A-z].
#[:alnum:]: alphanumeric characters, equivalent to [[:alpha:][:digit:]] or [A-z0-9].
#\w: word characters, equivalent to [[:alnum:]_] or [A-z0-9_].
#\W: not word, equivalent to [^A-z0-9_].
#[:xdigit:]: hexadecimal digits (base 16), 0 1 2 3 4 5 6 7 8 9 A B C D E F a b c d e f, equivalent to  [0-9A-Fa-f].
#[:blank:]: blank characters, i.e. space and tab.
#[:space:]: space characters: tab, newline, vertical tab, form feed, carriage return, space.
#\s: space, ` `.
#\S: not space.
#[:punct:]: punctuation characters, ! " # $ % & ' ( ) * + , - . / : ; < = > ? @ [  ] ^ _ ` { | } ~.
#[:graph:]: graphical (human readable) characters: equivalent to [[:alnum:][:punct:]].
#[:print:]: printable characters, equivalent to [[:alnum:][:punct:]\\s].
#[:cntrl:]: control characters, like \n or \r, [\x00-\x1F\x7F].

#Syntax Standards
#POSIX extended regular expressions (default)
#Perl-like regular expressions.

#One more type of regular expression fixed()

strings <- c("Axbc", "A.bc")

pattern <- "A.b"

grep(pattern, strings, value = TRUE)

grep(pattern, strings, value = TRUE, fixed = TRUE)

##########################
#Link to refer for cheatsheet
#https://www.rstudio.com/wp-content/uploads/2016/09/RegExCheatsheet.pdf
################################



















  
